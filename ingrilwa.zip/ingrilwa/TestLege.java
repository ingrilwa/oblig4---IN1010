public class TestLege {
    private static int antallFeilet = 0;
    private static int antallPasserte = 0;
    private static int antallTester = 0;

    public static void testLege() {
        testUnntak();
        testCompareTo();
        System.out.println(antallTester + " tester ferdig");
        System.out.println(antallPasserte + " passerte, " + antallFeilet + " feil");
    }

    static void testUnntak() {
        Narkotisk narkotisk = new Narkotisk("narkotisk", 100, 10, 10);
        Lege lege = new Lege("Geir Kjetil");
        Lege spesslege = new Spesialist("Kent", "1234");
        Pasient pasient = new Pasient("Kjetil", "311201");
        int reit = 10;
        System.out.println("\nTester unntak:");

        try {
            lege.skrivHvitResept(narkotisk, pasient, reit);
            testFeilet("testUnntak", "HvitResept skal kaste et UlovligUtskrift-unntak her");
        } catch(UlovligUtskrift u) {
              testPasserte();
          }

        try {
            lege.skrivMilitaerresept(narkotisk, pasient, reit);
            testFeilet("testUnntak", "Militaerresept skal kaste et UlovligUtskrift-unntak her");
        } catch(UlovligUtskrift u) {
              testPasserte();
          }

        try {
            lege.skrivPResept(narkotisk, pasient);
            testFeilet("testUnntak", "PResept skal kaste et UlovligUtskrift-unntak her");
        } catch(UlovligUtskrift u) {
              testPasserte();
          }

        try {
            lege.skrivBlaaResept(narkotisk, pasient, reit);
            testFeilet("testUnntak", "BlaaResept skal kaste et UlovligUtskrift-unntak her");
        } catch(UlovligUtskrift u) {
              testPasserte();
          }

        try {
            spesslege.skrivBlaaResept(narkotisk, pasient, reit);
            testPasserte();
        } catch(UlovligUtskrift u) {
              testFeilet("testUnntak", "BlaaResept skal ikke kaste et UlovligUtskrift-unntak her");
          }

    }

    static void testCompareTo() {
        System.out.println("\nTester compareTo:");
        Lege lege1 = new Lege("Dr. Paus");
        Lege lege2 = new Lege("Dr. Ueland");
        if (lege1.compareTo(lege2) > 0) {
            testFeilet("testCompareTo", "strengen Dr. Paus skal vaere mindre enn Dr. Ueland, ikke stoerre enn");
        } else if (lege2.compareTo(lege1) == 0){
              testFeilet("testCompareTo", "strengen Dr. Paus skal vaere mindre enn Dr. Ueland, ikke lik");
          } else {
                testPasserte();
            }
    }

    static void testFeilet(String testmelding, String test) {
        System.out.println(test + " feilet: " + testmelding);
        antallFeilet += 1;
        antallTester += 1;
    }

    static void testPasserte() {
        System.out.println("Test "+antallTester +": OK");
        antallPasserte += 1;
        antallTester += 1;
    }
}
