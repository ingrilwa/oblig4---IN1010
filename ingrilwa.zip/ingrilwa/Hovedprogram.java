class Hovedprogram {
    public static void main(String[] args) {
        Legesystem legesystem = new Legesystem();
        legesystem.hovedLoekke();
    }
}
